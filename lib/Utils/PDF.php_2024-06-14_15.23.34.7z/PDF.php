<?php

/**
 *
 * @copyright Copyright (c) 2024, RCDevs (info@rcdevs.com)
 *
 * @license GNU AGPL version 3 or any later version
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 */

namespace OCA\OpenOTPSign\Utils;

use setasign\Fpdi\Fpdi;

class PDF extends Fpdi
{
	// Add watermark to each page
	function addWatermark($watermarkText)
	{
		$this->SetFont('Arial', 'B', 50);
		$this->SetTextColor(255, 192, 203);
		$this->RotatedText(35, 190, $watermarkText, 45);
	}

	// Rotate text
	function RotatedText($x, $y, $txt, $angle)
	{
		// Text rotation
		$this->Rotate($angle, $x, $y);
		$this->Text($x, $y, $txt);
		$this->Rotate(0);
	}

	// Rotate any element
	function Rotate($angle, $x = -1, $y = -1)
	{
		if ($x == -1) $x = $this->x;
		if ($y == -1) $y = $this->y;
		if ($this->angle != 0) $this->_out('Q');
		$this->angle = $angle;
		if ($angle != 0) {
			$angle *= M_PI / 180;
			$c = cos($angle);
			$s = sin($angle);
			$cx = $x * $this->k;
			$cy = ($this->h - $y) * $this->k;
			$this->_out(sprintf('q %.5F %.5F %.5F %.5F %.5F %.5F cm 1 0 0 1 %.5F %.5F cm', $c, $s, -$s, $c, $cx, $cy, -$cx, -$cy));
		}
	}
}

// $pdf = new PDF();
// $pdf->AddPage();

// // Import the first page of the existing PDF
// $pageCount = $pdf->setSourceFile('path/to/your/existing.pdf');
// for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
// 	$templateId = $pdf->importPage($pageNo);
// 	$size = $pdf->getTemplateSize($templateId);
// 	$pdf->AddPage($size['orientation'], [$size['width'], $size['height']]);
// 	$pdf->useTemplate($templateId);

// 	// Add the watermark to the imported page
// 	$pdf->addWatermark('DRAFT');
// }

// // Output the new PDF
// $pdf->Output('I', 'modified.pdf');
